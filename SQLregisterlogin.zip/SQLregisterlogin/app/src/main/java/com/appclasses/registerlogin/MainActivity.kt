package com.appclasses.registerlogin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.user_registration.*


class MainActivity : AppCompatActivity() {
    lateinit var handeler:DatabaseHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        handeler = DatabaseHelper(this)

        showHome()

        registration.setOnClickListener{
            showRegistration()
        }
        login.setOnClickListener{
            showLogIN()
        }
        save.setOnClickListener{
            handeler.insertUserData(name.text.toString())
        }
    }

    private fun showRegistration(){
        registration_layout.visibility=View.VISIBLE
        login_layout.visibility=View.GONE
        home_ll.visibility=View.GONE
    }
    private fun showLogIN(){
        registration_layout.visibility=View.VISIBLE
        login_layout.visibility=View.GONE
        home_ll.visibility=View.GONE
    }
    private fun showHome(){
        registration_layout.visibility=View.VISIBLE
        login_layout.visibility=View.GONE
        home_ll.visibility=View.GONE
    }
}
